#!/bin/bash
cd samples/javascript/tagging
npm install
npm test
cd ../vcenter
npm install
npm test


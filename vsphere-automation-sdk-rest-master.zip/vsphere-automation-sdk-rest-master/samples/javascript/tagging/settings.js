module.exports = {
   ssoService: { //SSO service connection information. Default values are commented out.
      host: '', //No default! Please provide a value.
      //port: 443,
      //path: '/sts/STSService/vsphere.local',
      username: '', //SSO username. No default! Please provide a value.
      password: '' //SSO password. No default! Please provide a value.
   },
   endpoint: { //Endpoint connection information. Default values are commented out.
      host: '', //No default! Please provide a value.
      //,port: 443
      //,path: '/'
   }
}
